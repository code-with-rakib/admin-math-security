<?php
/**
 * Plugin Name: Admin Math Security
 * Plugin URI: https://github.com/code-with-rakib/admin-math-security
 * Description: Admin login এর সময় অতিরিক্ত Math Question সিকিউরিটি।
 * Version: 1.0
 * Author: Rakib Hasan
 * Author URI: https://codewithrakib.com
 * License: GPLv2 or later
 */


// Add math question field to login form
add_action('login_form', 'ams_add_math_question');
function ams_add_math_question() {
    if (!session_id()) {
        session_start();
    }

    // Random অংক তৈরি
    $num1 = rand(1, 10);
    $num2 = rand(1, 10);
    $_SESSION['ams_answer'] = $num1 + $num2;

    echo '<p>
        <label for="ams_math">নিরাপত্তা প্রশ্ন: '. $num1 .' + '. $num2 .' = ?<br />
        <input type="text" name="ams_math" class="input" value="" size="25" /></label>
    </p>';
}

// Validate answer
add_filter('authenticate', 'ams_validate_math_question', 30, 3);
function ams_validate_math_question($user, $username, $password) {
    if (!session_id()) {
        session_start();
    }

    // শুধুমাত্র admin login হলে চেক হবে
    if (isset($_POST['log']) && isset($_POST['pwd'])) {
        if (isset($_POST['ams_math'])) {
            $user_answer = intval(trim($_POST['ams_math']));
            $correct_answer = isset($_SESSION['ams_answer']) ? intval($_SESSION['ams_answer']) : 0;

            if ($user_answer !== $correct_answer) {
                return new WP_Error('ams_math_error', __('<strong>ERROR</strong>: নিরাপত্তা প্রশ্নের উত্তর ভুল হয়েছে।'));
            }
        } else {
            return new WP_Error('ams_math_missing', __('<strong>ERROR</strong>: অনুগ্রহ করে নিরাপত্তা প্রশ্নের উত্তর দিন।'));
        }
    }

    return $user;
}
